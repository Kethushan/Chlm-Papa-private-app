# Papa + Chlm Love Apps

Two Android flavor APKs:
- Papa (`com.papachlm.love.papa`)
- Chlm (`com.papachlm.love.chlm`)

Included:
- Dark romantic UI
- 💞 metallic-heart app icon
- Pairing code 312026
- Local Papa/Chlm voice assets
- Special heart animation
- Text chat UI
- Voice/video call UI shell
- GitHub Actions build workflow

## Important
This repository is the **UI/prototype build**. Real cross-device chat, push notifications, voice/video calling and delivery of the special heart event require a backend/signaling service (e.g. Firebase/Supabase + WebRTC/STUN/TURN). No backend credentials were supplied, so none are hard-coded.

GitHub Actions will build the two APKs. Upload this project to a GitHub repository, then open Actions → Build Papa and Chlm APKs → Run workflow. The APKs appear under the workflow Artifacts.
